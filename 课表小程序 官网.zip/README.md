

# 「课表」 Introduction Page

「课表」 is a WeApp，this is the page to introduce the micro program.

- [kb.mayuko.cn](http://kb.mayuko.cn/)




# Introduction

- [第一个小程序 「课表」](https://blog.mayuko.cn/archives/2604/)

- [「课表」v2.0](https://blog.mayuko.cn/archives/2685/)




## Licence

 © MIT 